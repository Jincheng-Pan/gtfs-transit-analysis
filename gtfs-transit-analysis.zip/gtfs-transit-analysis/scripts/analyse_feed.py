from gtfs_transit_analysis.cli import main

if __name__ == "__main__":
    main()
